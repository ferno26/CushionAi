#!/bin/sh
set -eu
rm -rf tests/out
mkdir -p tests/out
javac -d tests/out app/src/main/java/com/foxpool/trainer/PhysicsEngine.java tests/PhysicsSmokeTest.java
java -cp tests/out com.foxpool.trainer.PhysicsSmokeTest
