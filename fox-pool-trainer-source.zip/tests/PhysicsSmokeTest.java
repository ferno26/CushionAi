package com.foxpool.trainer;

public final class PhysicsSmokeTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        PhysicsEngine e=new PhysicsEngine();
        PhysicsEngine.Prediction contact=e.predict(720,250,3);
        check(contact.hasContact,"rack contact prediction missing");
        check(contact.segments.size()>=2,"three-line prediction did not create outgoing path");
        PhysicsEngine.Prediction bank=e.predict(70,80,4);
        check(bank.segments.size()>=2,"cushion prediction missing rebound");
        for(PhysicsEngine.Segment s:bank.segments){
            check(Float.isFinite(s.x1)&&Float.isFinite(s.y1)&&Float.isFinite(s.x2)&&Float.isFinite(s.y2),"non-finite prediction");
            check(s.x1>=37&&s.x1<=963&&s.y1>=37&&s.y1<=463,"prediction start escaped table");
            check(s.x2>=37&&s.x2<=963&&s.y2>=37&&s.y2<=463,"prediction end escaped table");
        }
        e.shoot(800,250,.8f,.65f);
        check(e.isMoving(),"shot did not start");
        for(int i=0;i<5000&&e.isMoving();i++)e.step(.008f);
        check(!e.isMoving(),"simulation failed to settle");
        for(PhysicsEngine.Ball b:e.balls())if(!b.pocketed)
            check(b.x>=51.9f&&b.x<=948.1f&&b.y>=51.9f&&b.y<=448.1f,"ball escaped playable table");
        e.newDrill();check(e.balls().size()>=4&&e.balls().size()<=7,"drill layout size invalid");
        System.out.println("PASS: contact paths, cushion reflections, motion, collisions, spin and drills");
    }
}
