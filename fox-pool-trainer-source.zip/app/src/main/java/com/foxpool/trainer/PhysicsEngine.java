package com.foxpool.trainer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Deterministic equal-mass 2D pool simulation in table coordinates. */
public final class PhysicsEngine {
    public static final float WIDTH=1000f,HEIGHT=500f,RADIUS=14f;
    private static final float LEFT=38f,TOP=38f,RIGHT=WIDTH-38f,BOTTOM=HEIGHT-38f;
    private static final float RESTITUTION=.93f,FRICTION=72f,STOP_SPEED=4f,POCKET_RADIUS=27f;

    public static final class Ball {
        public float x,y,vx,vy,spin;
        public final int number;
        public boolean pocketed;
        Ball(int number,float x,float y){this.number=number;this.x=x;this.y=y;}
        public Ball copy(){Ball b=new Ball(number,x,y);b.vx=vx;b.vy=vy;b.spin=spin;b.pocketed=pocketed;return b;}
    }
    public static final class Segment {
        public final float x1,y1,x2,y2;
        public final int kind;
        Segment(float x1,float y1,float x2,float y2,int kind){this.x1=x1;this.y1=y1;this.x2=x2;this.y2=y2;this.kind=kind;}
    }
    public static final class Prediction {
        public final List<Segment> segments=new ArrayList<>();
        public float contactX,contactY;
        public boolean hasContact;
    }
    private static final class Hit {
        float t=Float.POSITIVE_INFINITY,x,y,nx,ny;
        int ball=-1;
        boolean wall;
    }

    private final ArrayList<Ball> balls=new ArrayList<>();
    private final Random random=new Random(8626L);
    private boolean moving;
    private int shots,pocketedCount;

    public PhysicsEngine(){resetRack();}
    public List<Ball> balls(){return balls;}
    public Ball cue(){return balls.get(0);}
    public boolean isMoving(){return moving;}
    public int shots(){return shots;}
    public int pocketedCount(){return pocketedCount;}

    public void resetRack(){
        balls.clear();balls.add(new Ball(0,270,250));
        int n=1;float startX=670;
        for(int row=0;row<5;row++)for(int col=0;col<=row;col++){
            float x=startX+row*(RADIUS*1.78f),y=250+(col-row*.5f)*(RADIUS*2.06f);
            balls.add(new Ball(n++,x,y));
        }
        moving=false;shots=0;pocketedCount=0;
    }
    public void newDrill(){
        balls.clear();balls.add(new Ball(0,180+random.nextFloat()*230,110+random.nextFloat()*280));
        int count=3+random.nextInt(4);
        for(int i=1;i<=count;i++){
            Ball candidate;
            int guard=0;
            do{candidate=new Ball(i,430+random.nextFloat()*430,80+random.nextFloat()*340);guard++;}while(overlaps(candidate)&&guard<100);
            balls.add(candidate);
        }
        moving=false;shots=0;pocketedCount=0;
    }
    private boolean overlaps(Ball candidate){
        for(Ball b:balls)if(!b.pocketed&&distance(candidate.x,candidate.y,b.x,b.y)<RADIUS*2.3f)return true;
        return false;
    }
    public void moveBall(int index,float x,float y){
        if(index<0||index>=balls.size()||moving)return;
        Ball b=balls.get(index);b.pocketed=false;b.vx=b.vy=0;
        b.x=clamp(x,LEFT+RADIUS,RIGHT-RADIUS);b.y=clamp(y,TOP+RADIUS,BOTTOM-RADIUS);
        for(int pass=0;pass<3;pass++)for(int i=0;i<balls.size();i++)if(i!=index){
            Ball o=balls.get(i);if(o.pocketed)continue;float dx=b.x-o.x,dy=b.y-o.y,d=(float)Math.hypot(dx,dy);
            if(d<RADIUS*2&&d>.01f){float push=RADIUS*2-d;b.x+=dx/d*push;b.y+=dy/d*push;}
        }
    }
    public void shoot(float aimX,float aimY,float power,float sideSpin){
        Ball cue=cue();if(moving||cue.pocketed)return;
        float dx=aimX-cue.x,dy=aimY-cue.y,m=(float)Math.hypot(dx,dy);if(m<1)return;
        float speed=260+clamp(power,0,1)*950;cue.vx=dx/m*speed;cue.vy=dy/m*speed;cue.spin=clamp(sideSpin,-1,1);
        moving=true;shots++;
    }
    public void step(float dt){
        if(!moving)return;dt=Math.min(.025f,Math.max(.001f,dt));
        for(Ball b:balls){
            if(b.pocketed)continue;b.x+=b.vx*dt;b.y+=b.vy*dt;
            checkPocket(b);if(b.pocketed)continue;
            boolean rail=false;
            if(b.x-RADIUS<LEFT){b.x=LEFT+RADIUS;b.vx=Math.abs(b.vx)*RESTITUTION;rail=true;}
            else if(b.x+RADIUS>RIGHT){b.x=RIGHT-RADIUS;b.vx=-Math.abs(b.vx)*RESTITUTION;rail=true;}
            if(b.y-RADIUS<TOP){b.y=TOP+RADIUS;b.vy=Math.abs(b.vy)*RESTITUTION;rail=true;}
            else if(b.y+RADIUS>BOTTOM){b.y=BOTTOM-RADIUS;b.vy=-Math.abs(b.vy)*RESTITUTION;rail=true;}
            if(rail&&Math.abs(b.spin)>.01f){float vx=b.vx,vy=b.vy;b.vx=vx-vy*b.spin*.11f;b.vy=vy+vx*b.spin*.11f;b.spin*=.72f;}
        }
        for(int pass=0;pass<2;pass++)for(int i=0;i<balls.size();i++)for(int j=i+1;j<balls.size();j++)resolve(balls.get(i),balls.get(j));
        boolean any=false;
        for(Ball b:balls){
            if(b.pocketed)continue;float speed=(float)Math.hypot(b.vx,b.vy);
            if(speed>0){float next=Math.max(0,speed-FRICTION*dt);if(next<STOP_SPEED){b.vx=b.vy=0;}else{b.vx*=next/speed;b.vy*=next/speed;any=true;}}
        }
        moving=any;
        if(!moving&&cue().pocketed){cue().pocketed=false;cue().x=270;cue().y=250;cue().vx=cue().vy=0;}
    }
    private void resolve(Ball a,Ball b){
        if(a.pocketed||b.pocketed)return;float dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy,min=RADIUS*2;
        if(d2>=min*min||d2<.0001f)return;float d=(float)Math.sqrt(d2),nx=dx/d,ny=dy/d,over=min-d;
        a.x-=nx*over*.5f;a.y-=ny*over*.5f;b.x+=nx*over*.5f;b.y+=ny*over*.5f;
        float rel=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;if(rel>=0)return;
        float impulse=-(1f+.96f)*rel*.5f;a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny;
        b.spin+=a.spin*.22f;a.spin*=.65f;
    }
    private void checkPocket(Ball b){
        float[][] p={{LEFT,TOP},{(LEFT+RIGHT)/2,TOP},{RIGHT,TOP},{LEFT,BOTTOM},{(LEFT+RIGHT)/2,BOTTOM},{RIGHT,BOTTOM}};
        for(float[] q:p)if(distance(b.x,b.y,q[0],q[1])<POCKET_RADIUS){b.pocketed=true;b.vx=b.vy=0;if(b.number!=0)pocketedCount++;return;}
    }

    public Prediction predict(float aimX,float aimY,int bounces){
        Prediction out=new Prediction();Ball cue=cue();if(cue.pocketed)return out;
        float dx=aimX-cue.x,dy=aimY-cue.y,m=(float)Math.hypot(dx,dy);if(m<1)return out;dx/=m;dy/=m;
        Hit first=nextHit(cue.x,cue.y,dx,dy,0);
        if(first.t==Float.POSITIVE_INFINITY)return out;
        out.segments.add(new Segment(cue.x,cue.y,first.x,first.y,0));
        if(first.ball>0){
            Ball target=balls.get(first.ball);float nx=target.x-first.x,ny=target.y-first.y,nm=(float)Math.hypot(nx,ny);if(nm<.1f){nx=dx;ny=dy;}else{nx/=nm;ny/=nm;}
            out.contactX=first.x;out.contactY=first.y;out.hasContact=true;
            trace(out,target.x,target.y,nx,ny,first.ball,Math.max(0,bounces),1,2);
            float dot=dx*nx+dy*ny,tx=dx-nx*dot,ty=dy-ny*dot,tm=(float)Math.hypot(tx,ty);
            if(tm>.08f)trace(out,first.x,first.y,tx/tm,ty/tm,0,Math.min(2,Math.max(0,bounces)),2,1);
        }else{
            traceFromWall(out,first,dx,dy,0,Math.max(0,bounces),0);
        }
        return out;
    }
    private void trace(Prediction out,float sx,float sy,float dx,float dy,int excluded,int bounces,int kind,int comboDepth){
        float x=sx,y=sy;int remaining=bounces;
        for(int guard=0;guard<12;guard++){
            Hit h=nextHit(x,y,dx,dy,excluded);if(h.t==Float.POSITIVE_INFINITY)return;
            out.segments.add(new Segment(x,y,h.x,h.y,kind));
            if(h.ball>=0){
                if(comboDepth>0){Ball next=balls.get(h.ball);float nx=next.x-h.x,ny=next.y-h.y,nm=(float)Math.hypot(nx,ny);if(nm>.1f)trace(out,next.x,next.y,nx/nm,ny/nm,h.ball,remaining,3,comboDepth-1);}
                return;
            }
            if(!h.wall||remaining--<=0)return;
            float dot=dx*h.nx+dy*h.ny;dx-=2*dot*h.nx;dy-=2*dot*h.ny;x=h.x+dx*.2f;y=h.y+dy*.2f;
        }
    }
    private void traceFromWall(Prediction out,Hit h,float dx,float dy,int excluded,int bounces,int kind){
        float dot=dx*h.nx+dy*h.ny;dx-=2*dot*h.nx;dy-=2*dot*h.ny;
        trace(out,h.x+dx*.2f,h.y+dy*.2f,dx,dy,excluded,Math.max(0,bounces-1),kind,0);
    }
    private Hit nextHit(float sx,float sy,float dx,float dy,int excluded){
        Hit out=new Hit();float minX=LEFT+RADIUS,maxX=RIGHT-RADIUS,minY=TOP+RADIUS,maxY=BOTTOM-RADIUS;
        if(dx<-.0001f)wallHit(out,(minX-sx)/dx,minX,sy+(minX-sx)/dx*dy,1,0);
        if(dx>.0001f)wallHit(out,(maxX-sx)/dx,maxX,sy+(maxX-sx)/dx*dy,-1,0);
        if(dy<-.0001f)wallHit(out,(minY-sy)/dy,sx+(minY-sy)/dy*dx,minY,0,1);
        if(dy>.0001f)wallHit(out,(maxY-sy)/dy,sx+(maxY-sy)/dy*dx,maxY,0,-1);
        for(int i=0;i<balls.size();i++){
            if(i==excluded)continue;Ball b=balls.get(i);if(b.pocketed)continue;
            float ox=sx-b.x,oy=sy-b.y,bb=2*(dx*ox+dy*oy),c=ox*ox+oy*oy-4*RADIUS*RADIUS,disc=bb*bb-4*c;
            if(disc<0)continue;float t=(-bb-(float)Math.sqrt(disc))/2;if(t>.5f&&t<out.t){out.t=t;out.x=sx+dx*t;out.y=sy+dy*t;out.ball=i;out.wall=false;}
        }
        return out;
    }
    private void wallHit(Hit h,float t,float x,float y,float nx,float ny){if(t>.5f&&t<h.t){h.t=t;h.x=x;h.y=y;h.nx=nx;h.ny=ny;h.ball=-1;h.wall=true;}}
    private static float distance(float x,float y,float a,float b){return (float)Math.hypot(x-a,y-b);}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
}
