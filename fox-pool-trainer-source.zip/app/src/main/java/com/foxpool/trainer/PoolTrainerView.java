package com.foxpool.trainer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Interactive practice table: drag balls, aim anywhere, preview the path, then shoot. */
final class PoolTrainerView extends View {
    private static final int[] BALL_COLORS={0xFFF4F1DE,0xFFFFD23F,0xFF2D7DD2,0xFFE84855,0xFF8D5FD3,0xFFFF8C42,0xFF2AB673,0xFF8C2F39,0xFF1E2430,0xFFFFD23F,0xFF2D7DD2,0xFFE84855,0xFF8D5FD3,0xFFFF8C42,0xFF2AB673,0xFF8C2F39};
    private static final String[] BUTTONS={"SHOOT","RESET RACK","NEW DRILL","GUIDES","BOUNCES","SIDE SPIN"};
    private final PhysicsEngine engine=new PhysicsEngine();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path=new Path();
    private final ArrayList<RectF> buttonRects=new ArrayList<>();
    private RectF table=new RectF(),powerRect=new RectF();
    private float sx=1,sy=1,aimX=580,aimY=250,power=.62f,spin=0;
    private int bounces=2,dragBall=-1;
    private boolean guides=true,dragAim,dragPower;
    private long lastNanos;

    PoolTrainerView(Context context){super(context);setBackgroundColor(0xFF081017);paint.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);layout();
        long now=System.nanoTime();if(lastNanos==0)lastNanos=now;
        float elapsed=Math.min(.05f,(now-lastNanos)/1_000_000_000f);lastNanos=now;
        if(engine.isMoving()){for(int i=0;i<3;i++)engine.step(elapsed/3f);postInvalidateOnAnimation();}
        drawTable(c);
        if(guides&&!engine.isMoving())drawPrediction(c);
        drawBalls(c);drawAimHandle(c);drawMenu(c);
    }
    private void layout(){
        float menu=Math.min(dp(250),getWidth()*.27f),available=getWidth()-menu;
        float margin=dp(12),tw=available-margin*2,th=Math.min(getHeight()-margin*2,tw*.5f);
        tw=th*2;float left=(available-tw)*.5f,top=(getHeight()-th)*.5f;
        table.set(left,top,left+tw,top+th);sx=table.width()/PhysicsEngine.WIDTH;sy=table.height()/PhysicsEngine.HEIGHT;
        float mx=available+dp(10),mw=menu-dp(20),y=dp(62);buttonRects.clear();
        float bh=dp(36),gap=dp(7);
        for(int i=0;i<BUTTONS.length;i++){buttonRects.add(new RectF(mx,y,mx+mw,y+bh));y+=bh+gap;}
        powerRect.set(mx,getHeight()-dp(58),mx+mw,getHeight()-dp(31));
    }
    private void drawTable(Canvas c){
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFF321D18);c.drawRoundRect(expand(table,dp(11)),dp(22),dp(22),paint);
        paint.setColor(0xFF8D3324);c.drawRoundRect(expand(table,dp(7)),dp(18),dp(18),paint);
        paint.setColor(0xFF087D78);c.drawRoundRect(table,dp(13),dp(13),paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(0x554AF1D2);
        c.drawLine(tx(PhysicsEngine.WIDTH*.25f),table.top,tx(PhysicsEngine.WIDTH*.25f),table.bottom,paint);
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFF06090D);
        float[][] pockets={{38,38},{500,38},{962,38},{38,462},{500,462},{962,462}};
        for(float[] p:pockets)c.drawCircle(tx(p[0]),ty(p[1]),dp(14),paint);
    }
    private void drawBalls(Canvas c){
        float r=PhysicsEngine.RADIUS*sx;
        for(PhysicsEngine.Ball b:engine.balls()){
            if(b.pocketed)continue;float x=tx(b.x),y=ty(b.y);
            paint.setStyle(Paint.Style.FILL);paint.setColor(0x66000000);c.drawCircle(x+dp(2),y+dp(3),r*1.05f,paint);
            int color=BALL_COLORS[Math.floorMod(b.number,BALL_COLORS.length)];paint.setColor(color);c.drawCircle(x,y,r,paint);
            if(b.number>8){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(r*.44f);paint.setColor(0xFFF4F1DE);c.drawCircle(x,y,r*.72f,paint);paint.setStyle(Paint.Style.FILL);}
            paint.setColor(0xFFF8F5E6);c.drawCircle(x,y,r*.43f,paint);
            if(b.number==0){paint.setColor(0xFFE84855);c.drawCircle(x+r*.2f,y-r*.28f,r*.11f,paint);}
            else{paint.setColor(0xFF15202B);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(Math.max(dp(8),r*.66f));c.drawText(String.valueOf(b.number),x,y+paint.getTextSize()*.34f,paint);}
        }
    }
    private void drawPrediction(Canvas c){
        PhysicsEngine.Prediction p=engine.predict(aimX,aimY,bounces);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);
        for(PhysicsEngine.Segment s:p.segments){
            int color=s.kind==0?0xFFE8FAFF:s.kind==1?0xFFFFD85A:s.kind==2?0xFF77F4B2:0xFFFF7DD8;
            paint.setColor(0xA8000000);paint.setStrokeWidth(dp(5));c.drawLine(tx(s.x1),ty(s.y1),tx(s.x2),ty(s.y2),paint);
            paint.setColor(color);paint.setStrokeWidth(dp(s.kind==0?2.4f:2f));c.drawLine(tx(s.x1),ty(s.y1),tx(s.x2),ty(s.y2),paint);
        }
        if(p.hasContact){paint.setColor(0xFFE8FAFF);paint.setStrokeWidth(dp(2));c.drawCircle(tx(p.contactX),ty(p.contactY),PhysicsEngine.RADIUS*sx,paint);}
    }
    private void drawAimHandle(Canvas c){
        if(engine.isMoving())return;float x=tx(aimX),y=ty(aimY);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(0xFF73F6B5);c.drawCircle(x,y,dp(10),paint);
        c.drawLine(x-dp(15),y,x+dp(15),y,paint);c.drawLine(x,y-dp(15),x,y+dp(15),paint);
    }
    private void drawMenu(Canvas c){
        float x=getWidth()-Math.min(dp(250),getWidth()*.27f);
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFF111D27);c.drawRect(x,0,getWidth(),getHeight(),paint);
        paint.setColor(0xFF73F6B5);paint.setTextAlign(Paint.Align.LEFT);paint.setTextSize(dp(18));c.drawText("FOX POOL TRAINER",x+dp(12),dp(28),paint);
        paint.setColor(0xFFAEC2CF);paint.setTextSize(dp(10));c.drawText("Drag balls • tap table to aim",x+dp(12),dp(46),paint);
        for(int i=0;i<buttonRects.size();i++){
            RectF r=buttonRects.get(i);paint.setColor(i==0?0xFF246D55:0xFF1D2D39);c.drawRoundRect(r,dp(8),dp(8),paint);
            String text=BUTTONS[i];
            if(i==3)text+="  "+(guides?"ON":"OFF");
            if(i==4)text+="  "+bounces;
            if(i==5)text+="  "+(spin==0?"0":spin>0?"+RIGHT":"-LEFT");
            paint.setColor(i==0?Color.WHITE:0xFFD7E6EC);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(dp(11));c.drawText(text,r.centerX(),r.centerY()+dp(4),paint);
        }
        paint.setTextAlign(Paint.Align.LEFT);paint.setColor(0xFFAEC2CF);paint.setTextSize(dp(10));c.drawText("POWER  "+Math.round(power*100)+"%",powerRect.left,powerRect.top-dp(5),paint);
        paint.setColor(0xFF263946);c.drawRoundRect(powerRect,dp(10),dp(10),paint);
        RectF fill=new RectF(powerRect.left,powerRect.top,powerRect.left+powerRect.width()*power,powerRect.bottom);paint.setColor(0xFF73F6B5);c.drawRoundRect(fill,dp(10),dp(10),paint);
        paint.setColor(0xFF91A8B6);paint.setTextSize(dp(9));c.drawText("Shots "+engine.shots()+"   Pocketed "+engine.pocketedCount(),powerRect.left,getHeight()-dp(12),paint);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        float x=e.getX(),y=e.getY();
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){
            if(powerRect.contains(x,y)){dragPower=true;setPower(x);return true;}
            for(int i=0;i<buttonRects.size();i++)if(buttonRects.get(i).contains(x,y)){perform(i);return true;}
            if(!table.contains(x,y)||engine.isMoving())return true;
            float wx=wx(x),wy=wy(y);dragBall=nearestBall(wx,wy,PhysicsEngine.RADIUS*2.3f);
            if(dragBall<0){dragAim=true;aimX=wx;aimY=wy;}
            invalidate();return true;
        }
        if(e.getActionMasked()==MotionEvent.ACTION_MOVE){
            if(dragPower){setPower(x);return true;}
            if(dragBall>=0){engine.moveBall(dragBall,wx(x),wy(y));invalidate();return true;}
            if(dragAim){aimX=clamp(wx(x),38,962);aimY=clamp(wy(y),38,462);invalidate();return true;}
        }
        if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){dragBall=-1;dragAim=false;dragPower=false;return true;}
        return true;
    }
    private void perform(int i){
        if(i==0){engine.shoot(aimX,aimY,power,spin);lastNanos=System.nanoTime();postInvalidateOnAnimation();}
        else if(i==1){engine.resetRack();aimX=580;aimY=250;invalidate();}
        else if(i==2){engine.newDrill();PhysicsEngine.Ball cue=engine.cue();aimX=cue.x+300;aimY=cue.y;invalidate();}
        else if(i==3){guides=!guides;invalidate();}
        else if(i==4){bounces=(bounces+1)%5;invalidate();}
        else if(i==5){spin=spin==0?.65f:spin>0?-.65f:0;invalidate();}
    }
    private int nearestBall(float x,float y,float max){int best=-1;float dBest=max;List<PhysicsEngine.Ball> all=engine.balls();for(int i=0;i<all.size();i++){PhysicsEngine.Ball b=all.get(i);if(b.pocketed)continue;float d=(float)Math.hypot(x-b.x,y-b.y);if(d<dBest){dBest=d;best=i;}}return best;}
    private void setPower(float x){power=clamp((x-powerRect.left)/powerRect.width(),.08f,1);invalidate();}
    private RectF expand(RectF r,float n){return new RectF(r.left-n,r.top-n,r.right+n,r.bottom+n);}
    private float tx(float x){return table.left+x*sx;}private float ty(float y){return table.top+y*sy;}
    private float wx(float x){return (x-table.left)/sx;}private float wy(float y){return (y-table.top)/sy;}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
}
