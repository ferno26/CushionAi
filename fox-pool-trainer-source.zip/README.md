# Fox Pool Trainer

An original offline Android practice simulator for learning pool shot geometry. It does not modify, inspect, automate, or overlay another game.

## Training features

- Drag-and-drop ball placement
- Deterministic equal-mass collision simulation
- Cue-ball, object-ball and combination-shot prediction
- Zero to four ball-radius-aware cushion rebounds
- Bank-shot visualization
- Power and side-spin controls
- Full rack and repeatable randomized drills
- No login, Internet permission, subscription, screen capture, or overlay permission

## Controls

Use landscape mode. Drag any ball to build a layout, then tap or drag on the table to position the green aim handle. Adjust power, side spin and bounce count from the right panel. Press SHOOT to run the actual physics simulation. NEW DRILL creates a compact practice layout.

## Build

Requires JDK 17, Android SDK 35 and Gradle 8.9. Run sh tests/run.sh followed by gradle :app:assembleDebug.

The GitHub Actions workflow publishes the signed debug APK as Fox-Pool-Trainer-APK.
