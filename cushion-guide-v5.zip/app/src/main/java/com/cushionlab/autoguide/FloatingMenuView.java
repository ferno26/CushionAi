package com.cushionlab.autoguide;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Small touchable controller window; the full-screen guideline window remains untouchable. */
final class FloatingMenuView extends LinearLayout {
    private static final String[] COLOR_NAMES={"Cyan","Green","Yellow","Pink","Orange"};
    private final SharedPreferences prefs;
    private final WindowManager wm;
    private final WindowManager.LayoutParams params;
    private final LinearLayout panel;
    private final TextView handle;
    private float downX,downY;
    private int startX,startY;
    private boolean dragged;
    private boolean expanded=true;

    FloatingMenuView(Context context,SharedPreferences prefs,WindowManager wm,WindowManager.LayoutParams params){
        super(context);this.prefs=prefs;this.wm=wm;this.params=params;
        setOrientation(VERTICAL);setPadding(dp(6),dp(5),dp(6),dp(6));setBackground(round(0xEC111C25,14));
        handle=text("BALL GUIDE  •  drag / tap",12,0xFF72E6B1);
        handle.setGravity(Gravity.CENTER);handle.setPadding(dp(5),dp(7),dp(5),dp(7));addView(handle,new LayoutParams(-1,dp(36)));
        handle.setOnTouchListener(this::moveOrToggle);
        panel=new LinearLayout(context);panel.setOrientation(VERTICAL);addView(panel,new LayoutParams(-1,-2));
        toggle("Extended Guidelines","guides_enabled",true);
        toggle("3-Line Prediction","three_line",true);
        toggle("Bank / Cushion Prediction","bank_mode",true);
        slider("Rebounds","bounces",3,0,8);
        Button colour=button("");refreshColour(colour);
        colour.setOnClickListener(v->{int next=(prefs.getInt("line_color",0)+1)%COLOR_NAMES.length;prefs.edit().putInt("line_color",next).apply();refreshColour(colour);});
        panel.addView(colour,new LayoutParams(-1,dp(34)));
        slider("Thickness","guide_width",18,10,40);
        slider("Line opacity","trajectory_opacity",88,20,100);
        TextView pass=text("Touch-through canvas: ON",10,0xFF72E6B1);pass.setGravity(Gravity.CENTER);panel.addView(pass,new LayoutParams(-1,dp(24)));
    }

    private boolean moveOrToggle(View view,MotionEvent event){
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=event.getRawX();downY=event.getRawY();startX=params.x;startY=params.y;dragged=false;return true;
            case MotionEvent.ACTION_MOVE:
                int dx=Math.round(event.getRawX()-downX),dy=Math.round(event.getRawY()-downY);
                if(Math.abs(dx)+Math.abs(dy)>dp(5))dragged=true;
                if(dragged){params.x=Math.max(0,startX+dx);params.y=Math.max(0,startY+dy);try{wm.updateViewLayout(this,params);}catch(RuntimeException ignored){}}
                return true;
            case MotionEvent.ACTION_UP:
                if(dragged)prefs.edit().putInt("menu_x",params.x).putInt("menu_y",params.y).apply();else setExpanded(!expanded);
                return true;
            default:return false;
        }
    }
    private void setExpanded(boolean value){
        expanded=value;panel.setVisibility(value?VISIBLE:GONE);
        handle.setText(value?"BALL GUIDE  •  drag / tap":"☰");
        params.width=value?dp(238):dp(50);params.height=WindowManager.LayoutParams.WRAP_CONTENT;
        try{wm.updateViewLayout(this,params);}catch(RuntimeException ignored){}
    }
    private void toggle(String title,String key,boolean def){
        Switch control=new Switch(getContext());control.setText(title);control.setTextColor(0xFFE3EEF2);control.setTextSize(11);control.setPadding(dp(4),0,0,0);
        control.setChecked(prefs.getBoolean(key,def));control.setOnCheckedChangeListener((button,checked)->prefs.edit().putBoolean(key,checked).apply());
        panel.addView(control,new LayoutParams(-1,dp(34)));
    }
    private void slider(String title,String key,int def,int min,int max){
        LinearLayout row=new LinearLayout(getContext());row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label=text("",10,0xFFE3EEF2);label.setWidth(dp(82));
        SeekBar bar=new SeekBar(getContext());bar.setMax(max-min);bar.setProgress(Math.max(min,Math.min(max,prefs.getInt(key,def)))-min);
        label.setText(title+": "+(bar.getProgress()+min));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar seekBar,int progress,boolean fromUser){int n=progress+min;label.setText(title+": "+n);prefs.edit().putInt(key,n).apply();}
            @Override public void onStartTrackingTouch(SeekBar seekBar){}
            @Override public void onStopTrackingTouch(SeekBar seekBar){}
        });
        row.addView(label,new LayoutParams(dp(82),-1));row.addView(bar,new LayoutParams(0,-1,1));
        panel.addView(row,new LayoutParams(-1,dp(38)));
    }
    private Button button(String title){Button b=new Button(getContext());b.setText(title);b.setTextSize(10);b.setTextColor(0xFF72E6B1);b.setAllCaps(false);b.setBackground(round(0xFF1E2C37,8));return b;}
    private void refreshColour(Button b){b.setText("Line colour: "+COLOR_NAMES[Math.floorMod(prefs.getInt("line_color",0),COLOR_NAMES.length)]+"  (tap)");}
    private TextView text(String value,int sp,int color){TextView t=new TextView(getContext());t.setText(value);t.setTextSize(sp);t.setTextColor(color);return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),0xAA345064);return d;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
